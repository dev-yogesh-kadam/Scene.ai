"""SceneTranscribe: Whisper large-v3 text + wav2vec2 CTC forced alignment for word times + pyannote speakers.

Models (local folders under ComfyUI/models):
  whisper/whisper-large-v3                      openai/whisper-large-v3 (Apache-2.0)
  wav2vec2_align/en                             jonatasgrosman/wav2vec2-large-xlsr-53-english (Apache-2.0)
  wav2vec2_align/hi                             ai4bharat/indicwav2vec-hindi (Apache-2.0)
  pyannote/speaker-diarization-community-1      pyannote/speaker-diarization-community-1 (CC-BY-4.0)
"""
import json
import os
import re
import unicodedata

import torch
import torchaudio

import comfy.model_management
import folder_paths

SR = 16000
SENTENCE_END = re.compile(r"[.!?।॥]+[\"')\]]*$")


def _models(*parts):
    return os.path.join(folder_paths.models_dir, *parts)


def _mono16k(audio):
    wav = audio["waveform"][0].float().mean(0)
    if audio["sample_rate"] != SR:
        wav = torchaudio.functional.resample(wav, audio["sample_rate"], SR)
    return wav


def _whisper(wav, language, script, device):
    from transformers import WhisperForConditionalGeneration, WhisperProcessor
    path = _models("whisper", "whisper-large-v3")
    processor = WhisperProcessor.from_pretrained(path)
    model = WhisperForConditionalGeneration.from_pretrained(path, torch_dtype=torch.float16).to(device)
    long_form = len(wav) > 30 * SR
    feats = processor(wav.numpy(), sampling_rate=SR, return_tensors="pt", truncation=not long_form,
                      padding="longest" if long_form else "max_length", return_attention_mask=True)
    features = feats.input_features.to(device, torch.float16)
    if language == "auto":
        lang_id = model.detect_language(features[:, :, :3000])[0].item()
        language = processor.tokenizer.convert_ids_to_tokens(lang_id).strip("<|>")
    kw = {"return_timestamps": True, "return_segments": True, "task": "transcribe", "condition_on_prev_tokens": False,
          "language": language}
    if script.strip():
        # Whisper's prompt window is 224 tokens: keep the end of the script (names and spellings)
        kw["prompt_ids"] = torch.tensor(processor.get_prompt_ids(script.strip()[-600:]), device=device)
    out = model.generate(features, attention_mask=feats.attention_mask.to(device), **kw)
    segs = []
    for s in out["segments"][0]:
        text = processor.decode(s["tokens"], skip_special_tokens=True).strip()
        if text:
            segs.append({"start": float(s["start"]), "end": float(s["end"]), "text": text})
    model.to("cpu")
    return segs, language


def _aligner(lang, device):
    from transformers import AutoModelForCTC, Wav2Vec2CTCTokenizer
    path = _models("wav2vec2_align", "hi" if lang == "hi" else "en")
    tok = Wav2Vec2CTCTokenizer.from_pretrained(path)
    model = AutoModelForCTC.from_pretrained(path).to(device).eval()
    vocab = {k.lower(): v for k, v in tok.get_vocab().items()}
    return model, vocab, tok.pad_token_id


def _norm_char(c):
    return unicodedata.normalize("NFC", c.lower())


def _align_segment(model, vocab, blank, wav, seg, device, pad=0.5):
    """Word times for one Whisper segment, from CTC forced alignment only. Words with no alignable
    character (digits, symbols outside the aligner's alphabet) get start/end None."""
    words = seg["text"].split()
    t0 = max(0.0, seg["start"] - pad)
    t1 = min(len(wav) / SR, seg["end"] + pad)
    chunk = wav[int(t0 * SR):int(t1 * SR)]
    if len(chunk) < SR // 10:
        return [{"word": w, "start": None, "end": None} for w in words]
    with torch.no_grad():
        logits = model(chunk[None].to(device)).logits
    emission = torch.log_softmax(logits.float(), dim=-1)[0].cpu()
    sep = vocab.get("|", vocab.get(" "))
    tokens, owner = [], []
    for wi, w in enumerate(words):
        for c in w:
            c = _norm_char(c)
            if c in vocab:
                tokens.append(vocab[c]); owner.append(wi)
    if not tokens:
        return [{"word": w, "start": None, "end": None} for w in words]
    path, _ = torchaudio.functional.forced_align(emission[None], torch.tensor([tokens], dtype=torch.int32), blank=blank)
    spans = torchaudio.functional.merge_tokens(path[0], torch.zeros(path.shape[1]))
    frame_s = (t1 - t0) / emission.shape[0]
    out = [{"word": w, "start": None, "end": None} for w in words]
    for span, wi in zip(spans, owner):
        s, e = t0 + span.start * frame_s, t0 + span.end * frame_s
        if out[wi]["start"] is None:
            out[wi]["start"] = s
        out[wi]["end"] = e
    return out


def _diarize(wav, device, min_speakers, max_speakers):
    from pyannote.audio import Pipeline
    pipe = Pipeline.from_pretrained(_models("pyannote", "speaker-diarization-community-1"))
    pipe.to(torch.device(device))
    kw = {}
    if min_speakers > 0:
        kw["min_speakers"] = min_speakers
    if max_speakers > 0:
        kw["max_speakers"] = max_speakers
    out = pipe({"waveform": wav[None], "sample_rate": SR}, **kw)
    ann = getattr(out, "exclusive_speaker_diarization", None) or getattr(out, "speaker_diarization", out)
    return [(t.start, t.end, spk) for t, _, spk in ann.itertracks(yield_label=True)]


def _speaker_at(turns, s, e):
    best, best_ov = None, 0.0
    for ts, te, spk in turns:
        ov = min(e, te) - max(s, ts)
        if ov > best_ov:
            best, best_ov = spk, ov
    if best is None and turns:
        mid = (s + e) / 2
        best = min(turns, key=lambda t: min(abs(mid - t[0]), abs(mid - t[1])))[2]
    return best or "SPEAKER_00"


def _srt_time(t):
    ms = int(round(t * 1000))
    return "{:02d}:{:02d}:{:02d},{:03d}".format(ms // 3600000, ms // 60000 % 60, ms // 1000 % 60, ms % 1000)


class SceneTranscribe:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "audio": ("AUDIO",),
                "script": ("STRING", {"multiline": True, "default": "", "tooltip": "Optional episode script: used as Whisper's prompt for names and spellings."}),
                "language": (["auto", "en", "hi"], {"default": "auto"}),
                "diarize": ("BOOLEAN", {"default": True}),
                "min_speakers": ("INT", {"default": 0, "min": 0, "max": 20, "tooltip": "0 = automatic"}),
                "max_speakers": ("INT", {"default": 0, "min": 0, "max": 20, "tooltip": "0 = automatic"}),
                "filename_prefix": ("STRING", {"default": "scene_ai/transcript"}),
            },
        }

    RETURN_TYPES = ("STRING",)
    RETURN_NAMES = ("json",)
    OUTPUT_NODE = True
    FUNCTION = "run"
    CATEGORY = "scene_ai"

    def run(self, audio, script, language, diarize, min_speakers, max_speakers, filename_prefix):
        device = comfy.model_management.get_torch_device()
        comfy.model_management.unload_all_models()
        wav = _mono16k(audio)
        segs, lang = _whisper(wav, language, script, device)
        model, vocab, blank = _aligner(lang, device)
        words = []
        for seg in segs:
            words.extend(_align_segment(model, vocab, blank, wav, seg, device))
        model.to("cpu")
        turns = _diarize(wav, device, min_speakers, max_speakers) if diarize else []

        for w in words:
            w["speaker"] = _speaker_at(turns, w["start"], w["end"]) if (turns and w["start"] is not None) else ("SPEAKER_00" if not turns else None)
        # unaligned words take the speaker of the previous word
        last = "SPEAKER_00"
        for w in words:
            if w["speaker"] is None:
                w["speaker"] = last
            last = w["speaker"]

        # one segment per sentence; also split where the speaker changes
        sentences, cur = [], []
        for w in words:
            if cur and w["speaker"] != cur[-1]["speaker"]:
                sentences.append(cur); cur = []
            cur.append(w)
            if SENTENCE_END.search(w["word"]):
                sentences.append(cur); cur = []
        if cur:
            sentences.append(cur)
        segments = []
        for s in sentences:
            timed = [w for w in s if w["start"] is not None]
            if not timed:
                continue
            spk = max(set(w["speaker"] for w in s), key=lambda k: sum(1 for w in s if w["speaker"] == k))
            segments.append({"start": round(timed[0]["start"], 3), "end": round(timed[-1]["end"], 3), "speaker": spk,
                             "text": " ".join(w["word"] for w in s)})
        result = {"language": lang, "segments": segments,
                  "words": [{"start": None if w["start"] is None else round(w["start"], 3),
                             "end": None if w["end"] is None else round(w["end"], 3),
                             "word": w["word"], "speaker": w["speaker"]} for w in words]}

        full_dir, name, counter, subfolder, _ = folder_paths.get_save_image_path(filename_prefix, folder_paths.get_output_directory())
        base = f"{name}_{counter:05}_"
        with open(os.path.join(full_dir, base + ".json"), "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False, indent=1)
        with open(os.path.join(full_dir, base + ".srt"), "w", encoding="utf-8") as f:
            for i, s in enumerate(segments, 1):
                f.write(f"{i}\n{_srt_time(s['start'])} --> {_srt_time(s['end'])}\n[{s['speaker']}] {s['text']}\n\n")
        files = [{"filename": base + ext, "subfolder": subfolder, "type": "output"} for ext in (".json", ".srt")]
        return {"ui": {"transcripts": files}, "result": (json.dumps(result, ensure_ascii=False),)}
