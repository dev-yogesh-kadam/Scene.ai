"""SceneLipSync: LatentSync 1.6 mouth re-render driven by a voice track.

Upstream code: third_party_LatentSync (github.com/bytedance/LatentSync, Apache-2.0).
Face landmarks come from MediaPipe Face Landmarker (Apache-2.0) instead of upstream's InsightFace
(whose pretrained models are non-commercial). Only LatentSync's 3 alignment points are needed:
the two eyebrow centres and the nose centre.

Models in ComfyUI/models/latentsync: latentsync_unet.pt + whisper/tiny.pt (ByteDance/LatentSync-1.6),
sd-vae-ft-mse/ (stabilityai/sd-vae-ft-mse), face_landmarker.task (MediaPipe).
"""
import math
import os
import sys
import types

import cv2
import numpy as np
import torch
import torchaudio

import comfy.model_management
import comfy.utils
import folder_paths

REPO = os.path.join(os.path.dirname(os.path.abspath(__file__)), "third_party_LatentSync")
MODELS = os.path.join(folder_paths.models_dir, "latentsync")

# MediaPipe face mesh indices
BROW_IMAGE_LEFT = [70, 63, 105, 66, 107, 55, 65, 52, 53, 46]       # subject's right eyebrow
BROW_IMAGE_RIGHT = [336, 296, 334, 293, 300, 276, 283, 282, 295, 285]
NOSE = [1, 2, 4, 5, 195, 197]


class _FaceSelector:
    """Stands in for LatentSync's InsightFace FaceDetector: returns (bbox, 106-point array) with the
    points LatentSync reads filled from MediaPipe, for the chosen face, tracked across frames."""

    def __init__(self, choice, index):
        import mediapipe as mp
        from mediapipe.tasks.python import BaseOptions, vision
        self.mp = mp
        opts = vision.FaceLandmarkerOptions(
            base_options=BaseOptions(model_asset_path=os.path.join(MODELS, "face_landmarker.task")),
            num_faces=8, min_face_detection_confidence=0.4, min_face_presence_confidence=0.4)
        self.landmarker = vision.FaceLandmarker.create_from_options(opts)
        self.choice, self.index = choice, index
        self.prev_center = None

    def detect(self, frame):
        h, w, _ = frame.shape
        res = self.landmarker.detect(self.mp.Image(image_format=self.mp.ImageFormat.SRGB, data=np.ascontiguousarray(frame)))
        faces = [np.array([[p.x * w, p.y * h] for p in lm]) for lm in res.face_landmarks]
        if not faces:
            return None
        centers = [f.mean(0) for f in faces]
        if self.prev_center is not None:
            k = int(np.argmin([np.linalg.norm(c - self.prev_center) for c in centers]))
            size = np.ptp(faces[k][:, 0])
            if np.linalg.norm(centers[k] - self.prev_center) > size:
                return None
        elif self.choice == "largest":
            k = int(np.argmax([np.ptp(f[:, 0]) * np.ptp(f[:, 1]) for f in faces]))
        else:
            order = sorted(range(len(faces)), key=lambda i: centers[i][0])
            k = {"left": order[0], "right": order[-1]}.get(self.choice, order[min(self.index, len(order) - 1)])
        self.prev_center = centers[k]
        return faces[k]

    @staticmethod
    def to_106(lm):
        pts = np.zeros((106, 2))
        pts[[43, 48, 49, 51, 50]] = lm[BROW_IMAGE_LEFT].mean(0)
        pts[101:106] = lm[BROW_IMAGE_RIGHT].mean(0)
        pts[[74, 77, 83, 86]] = lm[NOSE].mean(0)
        return pts


def _import_latentsync():
    if REPO not in sys.path:
        sys.path.insert(0, REPO)
    # upstream imports InsightFace here; LatentSync only needs the class name to exist
    stub = types.ModuleType("latentsync.utils.face_detector")
    stub.FaceDetector = None
    sys.modules.setdefault("latentsync.utils.face_detector", stub)
    from latentsync.models.unet import UNet3DConditionModel
    from latentsync.pipelines.lipsync_pipeline import LipsyncPipeline
    from latentsync.utils.image_processor import ImageProcessor, load_fixed_mask
    from latentsync.whisper.audio2feature import Audio2Feature
    return UNet3DConditionModel, LipsyncPipeline, ImageProcessor, load_fixed_mask, Audio2Feature


class SceneLipSync:
    @classmethod
    def INPUT_TYPES(cls):
        return {
            "required": {
                "images": ("IMAGE",),
                "voice": ("AUDIO",),
                "fps": ("FLOAT", {"default": 24.0, "min": 1.0, "max": 120.0}),
                "face": (["largest", "left", "right", "index"], {"default": "largest"}),
                "face_index": ("INT", {"default": 0, "min": 0, "max": 7, "tooltip": "Used when face = index: 0 = leftmost face"}),
                "steps": ("INT", {"default": 20, "min": 4, "max": 100}),
                "lips_strength": ("FLOAT", {"default": 1.5, "min": 1.0, "max": 3.0, "step": 0.1, "tooltip": "LatentSync guidance scale"}),
                "seed": ("INT", {"default": 1247, "min": 0, "max": 0xffffffffffffffff}),
            },
        }

    RETURN_TYPES = ("IMAGE", "AUDIO")
    RETURN_NAMES = ("images", "voice")
    FUNCTION = "sync"
    CATEGORY = "scene_ai"

    def sync(self, images, voice, fps, face, face_index, steps, lips_strength, seed):
        from diffusers import AutoencoderKL, DDIMScheduler
        from omegaconf import OmegaConf
        UNet3DConditionModel, LipsyncPipeline, ImageProcessor, load_fixed_mask, Audio2Feature = _import_latentsync()
        device = comfy.model_management.get_torch_device()
        comfy.model_management.unload_all_models()
        dtype = torch.float16
        n = images.shape[0]

        config = OmegaConf.load(os.path.join(REPO, "configs", "unet", "stage2_512.yaml"))
        res = config.data.resolution
        scheduler = DDIMScheduler.from_pretrained(os.path.join(REPO, "configs"))
        audio_encoder = Audio2Feature(model_path=os.path.join(MODELS, "whisper", "tiny.pt"), device=str(device),
                                      num_frames=config.data.num_frames, audio_feat_length=config.data.audio_feat_length)
        vae = AutoencoderKL.from_pretrained(os.path.join(MODELS, "sd-vae-ft-mse"), torch_dtype=dtype)
        vae.config.scaling_factor = 0.18215
        vae.config.shift_factor = 0
        unet, _ = UNet3DConditionModel.from_pretrained(OmegaConf.to_container(config.model), os.path.join(MODELS, "latentsync_unet.pt"), device="cpu")
        pipe = LipsyncPipeline(vae=vae, audio_encoder=audio_encoder, unet=unet.to(dtype=dtype), scheduler=scheduler).to(device)
        pipe.image_processor = ImageProcessor(res, device="cpu", mask_image=load_fixed_mask(res, os.path.join(REPO, "latentsync", "utils", "mask.png")))
        restorer = pipe.image_processor.restorer
        restorer.device = device
        restorer.mask = restorer.mask.to(device)
        restorer.fill_value = restorer.fill_value.to(device)

        # voice: 16 kHz mono, padded with silence or cut to exactly the video's length
        wav = voice["waveform"][0].float().mean(0)
        if voice["sample_rate"] != 16000:
            wav = torchaudio.functional.resample(wav, voice["sample_rate"], 16000)
        need = int(math.ceil(n / fps * 16000))
        wav = torch.nn.functional.pad(wav, (0, max(0, need + 16000 - wav.shape[0])))
        feats = audio_encoder._audio2feat(wav.numpy())
        chunks = audio_encoder.feature2chunks(feature_array=feats, fps=fps)[:n]

        # landmarks for the chosen face on every frame; gaps take the nearest found frame
        frames = (images.clamp(0, 1) * 255).round().to(torch.uint8).numpy()
        sel = _FaceSelector(face, face_index)
        lms = [sel.detect(f) for f in frames]
        found = [i for i, l in enumerate(lms) if l is not None]
        if not found:
            raise RuntimeError("No face found in the video")
        for i in range(n):
            if lms[i] is None:
                lms[i] = lms[min(found, key=lambda j: abs(j - i))]
        faces, affines = [], []
        for f, lm in zip(frames, lms):
            pts = sel.to_106(lm)
            l3 = np.round([pts[43], pts[101], pts[74]])
            crop, aff = restorer.align_warp_face(f.copy(), landmarks3=l3, smooth=True)
            crop_hw = crop.shape[:2]
            crop = torch.from_numpy(cv2.resize(crop, (res, res), interpolation=cv2.INTER_LANCZOS4)).permute(2, 0, 1)
            faces.append(crop)
            affines.append(aff)
        faces = torch.stack(faces)

        generator = torch.Generator(device=device).manual_seed(seed)
        do_cfg = lips_strength > 1.0
        scheduler.set_timesteps(steps, device=device)
        latents_all = pipe.prepare_latents(n, vae.config.latent_channels, res, res, dtype, device, generator)
        out_faces = []
        per = config.data.num_frames
        pbar = comfy.utils.ProgressBar(math.ceil(n / per))
        with torch.no_grad():
            for i in range(math.ceil(n / per)):
                a = torch.stack(chunks[i * per:(i + 1) * per]).to(device, dtype=dtype)
                if do_cfg:
                    a = torch.cat([torch.zeros_like(a), a])
                ref, masked, masks = pipe.image_processor.prepare_masks_and_masked_images(faces[i * per:(i + 1) * per], affine_transform=False)
                mask_lat, masked_lat = pipe.prepare_mask_latents(masks, masked, res, res, dtype, device, generator, do_cfg)
                ref_lat = pipe.prepare_image_latents(ref, device, dtype, generator, do_cfg)
                lat = latents_all[:, :, i * per:(i + 1) * per]
                for t in scheduler.timesteps:
                    x = torch.cat([lat] * 2) if do_cfg else lat
                    x = scheduler.scale_model_input(x, t)
                    x = torch.cat([x, mask_lat, masked_lat, ref_lat], dim=1)
                    eps = pipe.unet(x, t, encoder_hidden_states=a).sample
                    if do_cfg:
                        u, c = eps.chunk(2)
                        eps = u + lips_strength * (c - u)
                    lat = scheduler.step(eps, t, lat).prev_sample
                dec = pipe.decode_latents(lat)
                dec = pipe.paste_surrounding_pixels_back(dec, ref, 1 - masks, device, dtype)
                out_faces.append(dec)
                pbar.update(1)
            out = []
            for k, fc in enumerate(torch.cat(out_faces)):
                fc = torch.nn.functional.interpolate(fc[None].float(), size=crop_hw, mode="bicubic", antialias=True)[0]
                out.append(restorer.restore_img(frames[k], fc, affines[k]))
        pipe.to("cpu")
        del pipe, unet, vae, audio_encoder
        comfy.model_management.soft_empty_cache()

        result = torch.from_numpy(np.stack(out)).float() / 255.0
        v = voice["waveform"][0]
        keep = int(round(n / fps * voice["sample_rate"]))
        v = torch.nn.functional.pad(v, (0, max(0, keep - v.shape[-1])))[:, :keep]
        return (result, {"waveform": v[None], "sample_rate": voice["sample_rate"]})
