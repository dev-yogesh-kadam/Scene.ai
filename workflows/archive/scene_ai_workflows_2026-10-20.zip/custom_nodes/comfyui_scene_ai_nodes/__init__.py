"""Scene.ai helper nodes (local pack).

SceneQwenEditRefs  - Qwen Image Edit text encoder that takes up to 6 reference images.
                     Every input is optional, so a bypassed Load Image just drops out.
SceneAspectSize    - aspect ratio -> model render size + final output size.
SceneH3Chunk       - MiniMax H3 reference-to-video with 9 named optional image slots (anchor first) and a seconds input.
SceneH3ShotPins    - pin one keyframe per shot at given cut frames, which makes H3 cut on those exact frames.
SceneLipSync       - LatentSync 1.6 lip sync with MediaPipe face choice (lipsync.py).
SceneTranscribe    - timestamped transcript JSON + SRT (transcribe.py).
SceneSaveAudioWav  - save audio as 24-bit wav.
SceneVoiceSeparate - voice stem / music+fx stem of a long mix with HDemucs, in chunks, exact input length.
"""
import math

import os
import wave

import torch
import torchaudio

import comfy.model_management
import comfy.utils
import folder_paths
import node_helpers
import nodes
from comfy_extras.nodes_minimax_h3 import MiniMaxH3AddGuide, MiniMaxH3ReferenceToVideo

from .lipsync import SceneLipSync
from .transcribe import SceneTranscribe

QWEN_EDIT_TEMPLATE = (
    "<|im_start|>system\nDescribe the key features of the input image (color, shape, size, texture, objects, background), "
    "then explain how the user's text instruction should alter or modify the image. Generate a new image that meets the "
    "user's requirements while maintaining consistency with the original input where appropriate.<|im_end|>\n"
    "<|im_start|>user\n{}<|im_end|>\n<|im_start|>assistant\n"
)

# render size (Qwen Image native, ~1.3-1.6 MP, multiples of 16) and delivery size
ASPECTS = {
    "1:1": ((1328, 1328), (1536, 1536)),
    "16:9": ((1664, 928), (2752, 1536)),
    "9:16": ((928, 1664), (1536, 2752)),
    "4:3": ((1472, 1104), (2048, 1536)),
}


def _scale_to_area(samples, area, multiple):
    scale_by = math.sqrt(area / (samples.shape[3] * samples.shape[2]))
    w = max(multiple, round(samples.shape[3] * scale_by / multiple) * multiple)
    h = max(multiple, round(samples.shape[2] * scale_by / multiple) * multiple)
    return comfy.utils.common_upscale(samples, w, h, "area", "disabled")


def _stitch(images, height=1024, gap=16):
    """Put several images side by side on one grey canvas (same height)."""
    parts = []
    for img in images:
        s = img[:1].movedim(-1, 1)[:, :3]
        w = max(8, round(s.shape[3] * height / s.shape[2]))
        parts.append(comfy.utils.common_upscale(s, w, height, "area", "disabled"))
    total_w = sum(p.shape[3] for p in parts) + gap * (len(parts) - 1)
    canvas = torch.full((1, 3, height, total_w), 0.5, dtype=parts[0].dtype, device=parts[0].device)
    x = 0
    for p in parts:
        canvas[:, :, :, x:x + p.shape[3]] = p
        x += p.shape[3] + gap
    return canvas.movedim(1, -1)


class SceneQwenEditRefs:
    @classmethod
    def INPUT_TYPES(cls):
        opt = {f"image{i}": ("IMAGE",) for i in range(1, 7)}
        return {
            "required": {
                "clip": ("CLIP",),
                "vae": ("VAE",),
                "prompt": ("STRING", {"multiline": True, "dynamicPrompts": True}),
                "negative_prompt": ("STRING", {"multiline": True, "default": ""}),
                "width": ("INT", {"default": 1664, "min": 64, "max": 4096, "step": 16}),
                "height": ("INT", {"default": 928, "min": 64, "max": 4096, "step": 16}),
                "combine": (["stitch_2_to_6", "native"], {"default": "stitch_2_to_6",
                            "tooltip": "stitch_2_to_6: references 2-6 share one canvas (Picture 2). native: every reference is its own picture."}),
                "reference_megapixels": ("FLOAT", {"default": 1.0, "min": 0.25, "max": 2.5, "step": 0.05}),
            },
            "optional": opt,
        }

    RETURN_TYPES = ("CONDITIONING", "CONDITIONING")
    RETURN_NAMES = ("positive", "negative")
    FUNCTION = "encode"
    CATEGORY = "scene_ai"

    def encode(self, clip, vae, prompt, negative_prompt, width, height, combine, reference_megapixels, **kw):
        refs = [kw.get(f"image{i}") for i in range(1, 7)]
        refs = [r for r in refs if r is not None]
        if combine == "stitch_2_to_6" and len(refs) > 2:
            refs = refs[:1] + [_stitch(refs[1:])]

        images_vl, ref_latents, image_prompt = [], [], ""
        for i, image in enumerate(refs):
            samples = image[:1].movedim(-1, 1)[:, :3]
            images_vl.append(_scale_to_area(samples, 384 * 384, 1).movedim(1, -1))
            if i == 0 and abs(math.log((samples.shape[3] / samples.shape[2]) / (width / height))) < 0.1:
                # base image already has the output's shape: encode it at exactly the output size so edits stay pixel-aligned
                ref = comfy.utils.common_upscale(samples, width, height, "lanczos", "center")
            else:
                ref = _scale_to_area(samples, reference_megapixels * 1024 * 1024, 8)
            ref_latents.append(vae.encode(ref.movedim(1, -1)))
            image_prompt += "Picture {}: <|vision_start|><|image_pad|><|vision_end|>".format(i + 1)

        out = []
        for text in (prompt, negative_prompt):
            tokens = clip.tokenize(image_prompt + text, images=images_vl, llama_template=QWEN_EDIT_TEMPLATE)
            cond = clip.encode_from_tokens_scheduled(tokens)
            if ref_latents:
                cond = node_helpers.conditioning_set_values(cond, {"reference_latents": ref_latents}, append=True)
            out.append(cond)
        return (out[0], out[1])


class SceneAspectSize:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"aspect_ratio": (list(ASPECTS.keys()), {"default": "16:9"})}}

    RETURN_TYPES = ("INT", "INT", "INT", "INT", "INT")
    RETURN_NAMES = ("render_width", "render_height", "out_width", "out_height", "out_short_edge")
    FUNCTION = "size"
    CATEGORY = "scene_ai"

    def size(self, aspect_ratio):
        (rw, rh), (ow, oh) = ASPECTS[aspect_ratio]
        return (rw, rh, ow, oh, min(ow, oh))


H3_SLOTS = [
    ("background", "the scene: the location with everyone in their places. Keep this layout, the positions of the people and the look of the place"),
    ("character_1", "character 1"),
    ("character_2", "character 2"),
    ("character_3", "character 3"),
    ("character_4", "character 4"),
    ("character_5", "character 5"),
    ("prop_1", "a prop"),
    ("prop_2", "a second prop"),
    ("extra", "an extra reference (outfit, detail or style)"),
]


def h3_frames(seconds):
    """Frames H3 renders for a duration: round(24 * s) snapped up to the 17k + 5 grid."""
    n = max(5, round(seconds * 24))
    return n + (5 - n % 17) % 17


class SceneH3Chunk:
    @classmethod
    def INPUT_TYPES(cls):
        optional = {"vae": ("VAE",), "audio_vae": ("VAE",)}
        for name, _ in H3_SLOTS:
            optional[name] = ("IMAGE",)
        optional["motion_video"] = ("IMAGE",)
        optional["motion_video_audio"] = ("AUDIO",)
        optional["voice_sample"] = ("AUDIO",)
        return {
            "required": {
                "clip": ("CLIP",),
                "prompt": ("STRING", {"multiline": True, "dynamicPrompts": True}),
                "width": ("INT", {"default": 864, "min": 32, "max": nodes.MAX_RESOLUTION, "step": 32}),
                "height": ("INT", {"default": 480, "min": 32, "max": nodes.MAX_RESOLUTION, "step": 32}),
                "seconds": ("FLOAT", {"default": 6.0, "min": 0.25, "max": 15.0, "step": 0.01}),
                "describe_references": ("BOOLEAN", {"default": True, "tooltip": "Add a line in front of the prompt saying what each <Picture N> is."}),
            },
            "optional": optional,
        }

    RETURN_TYPES = ("CONDITIONING", "LATENT", "STRING", "INT", "FLOAT")
    RETURN_NAMES = ("positive", "latent", "final_prompt", "frames", "seconds_exact")
    FUNCTION = "build"
    CATEGORY = "scene_ai"

    def build(self, clip, prompt, width, height, seconds, describe_references,
              vae=None, audio_vae=None, motion_video=None, motion_video_audio=None, voice_sample=None, **images):
        ref_images, roles = {}, []
        for name, role in H3_SLOTS:
            img = images.get(name)
            if img is None:
                continue
            ref_images["ref_image_{}".format(len(ref_images))] = img
            roles.append("<Picture {}> is {}.".format(len(ref_images), role))
        ref_videos, ref_video_audios, ref_audios = {}, {}, {}
        audio_count = 0
        if motion_video is not None:
            ref_videos["ref_video_0"] = motion_video
            if motion_video_audio is not None and audio_vae is not None:
                ref_video_audios["ref_video_audio_0"] = motion_video_audio
                audio_count += 1
            roles.append("<Video 1> shows the motion and camera move to follow.")
        if voice_sample is not None and audio_vae is not None:
            ref_audios["ref_audio_0"] = voice_sample
            audio_count += 1
            roles.append("<Audio {}> is the voice of character 1.".format(audio_count))
        final_prompt = prompt
        if describe_references and roles:
            final_prompt = " ".join(roles) + "\n" + prompt
        positive, latent = MiniMaxH3ReferenceToVideo.execute(
            clip, final_prompt, width, height, h3_frames(seconds), "match", vae=vae, audio_vae=audio_vae,
            ref_images=ref_images, ref_videos=ref_videos, ref_video_audios=ref_video_audios, ref_audios=ref_audios).args
        frames = max(1, round(seconds * 24))
        return (positive, latent, final_prompt, frames, frames / 24.0)


class SceneH3ShotPins:
    @classmethod
    def INPUT_TYPES(cls):
        optional = {"shot_{}".format(i): ("IMAGE",) for i in range(1, 7)}
        return {
            "required": {
                "positive": ("CONDITIONING",),
                "latent": ("LATENT",),
                "vae": ("VAE",),
                "cut_frames": ("STRING", {"default": "", "tooltip": "Frame numbers where shots 2, 3, ... start, e.g. '48, 84, 156'. Empty = no pins."}),
            },
            "optional": optional,
        }

    RETURN_TYPES = ("CONDITIONING",)
    RETURN_NAMES = ("positive",)
    FUNCTION = "pin"
    CATEGORY = "scene_ai"

    def pin(self, positive, latent, vae, cut_frames, **shots):
        cuts = [int(c) for c in cut_frames.replace(";", ",").split(",") if c.strip()]
        starts = [0] + cuts
        for k, start in enumerate(starts):
            img = shots.get("shot_{}".format(k + 1))
            if img is None:
                continue
            positive = MiniMaxH3AddGuide.execute(positive, latent, start, vae=vae, image=img[:1]).args[0]
            if k + 1 < len(starts):
                # the same keyframe on the shot's last frame makes the cut land exactly on the next start
                positive = MiniMaxH3AddGuide.execute(positive, latent, starts[k + 1] - 1, vae=vae, image=img[:1]).args[0]
        return (positive,)


HDEMUCS_FILE = "hdemucs_high_trained.pt"
HDEMUCS_URL = "https://download.pytorch.org/torchaudio/models/hdemucs_high_trained.pt"
HDEMUCS_SR = 44100
HTDEMUCS_FT_VOCALS = "htdemucs_ft_vocals_04573f0d-f3cf25b2.th"
HTDEMUCS_FT_URL = "https://dl.fbaipublicfiles.com/demucs/hybrid_transformer/04573f0d-f3cf25b2.th"


def _load_separator(name, device):
    """Returns (forward(x[1, 2, n]) -> vocals[2, n], sample_rate)."""
    d = os.path.join(folder_paths.models_dir, "audio_separation")
    if name == "htdemucs_ft":
        from demucs.apply import apply_model
        from demucs.states import load_model
        path = os.path.join(d, HTDEMUCS_FT_VOCALS)
        if not os.path.isfile(path):
            raise FileNotFoundError(f"Put {HTDEMUCS_FT_VOCALS} in models/audio_separation (download: {HTDEMUCS_FT_URL})")
        model = load_model(path).eval()
        idx = model.sources.index("vocals")
        return (lambda x: apply_model(model, x, device=device, shifts=1, split=True, overlap=0.25, progress=False)[0, idx]), model.samplerate
    path = os.path.join(d, HDEMUCS_FILE)
    if not os.path.isfile(path):
        raise FileNotFoundError(f"Put {HDEMUCS_FILE} in models/audio_separation (download: {HDEMUCS_URL})")
    model = torchaudio.models.hdemucs_high(sources=["drums", "bass", "other", "vocals"])
    model.load_state_dict(torch.load(path, map_location="cpu", weights_only=True))
    model.eval().to(device)
    return (lambda x: model(x.to(device))[0, 3]), HDEMUCS_SR


class SceneVoiceSeparate:
    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {
            "audio": ("AUDIO",),
            "model": (["htdemucs_ft", "hdemucs_high"], {"default": "htdemucs_ft"}),
            "chunk_seconds": ("FLOAT", {"default": 30.0, "min": 5.0, "max": 120.0, "step": 1.0}),
            "overlap_seconds": ("FLOAT", {"default": 2.0, "min": 0.5, "max": 10.0, "step": 0.5}),
        }}

    RETURN_TYPES = ("AUDIO", "AUDIO")
    RETURN_NAMES = ("voice", "music_and_fx")
    FUNCTION = "separate"
    CATEGORY = "scene_ai"

    def separate(self, audio, model, chunk_seconds, overlap_seconds):
        device = comfy.model_management.get_torch_device()
        forward, model_sr = _load_separator(model, device)

        wav, sr = audio["waveform"][0].float(), audio["sample_rate"]
        n_in = wav.shape[-1]
        x = wav if wav.shape[0] == 2 else wav[:1].repeat(2, 1)
        if sr != model_sr:
            x = torchaudio.functional.resample(x, sr, model_sr)
        n = x.shape[-1]
        ref = x.mean(0)
        x = (x - ref.mean()) / (ref.std() + 1e-8)

        chunk = int(chunk_seconds * model_sr)
        ov = int(overlap_seconds * model_sr)
        voice = torch.zeros(2, n)
        weight = torch.zeros(n)
        fade = torch.linspace(0, 1, ov)
        pbar = comfy.utils.ProgressBar(max(1, math.ceil(n / (chunk - ov))))
        start = 0
        while start < n:
            end = min(n, start + chunk)
            with torch.no_grad():
                out = forward(x[None, :, start:end]).cpu()
            w = torch.ones(end - start)
            if start > 0:
                w[:ov] = fade[:end - start]
            if end < n:
                w[-ov:] = torch.minimum(w[-ov:], fade.flip(0))
            voice[:, start:end] += out * w
            weight[start:end] += w
            pbar.update(1)
            if end == n:
                break
            start = end - ov
        voice = voice / weight.clamp(min=1e-8) * (ref.std() + 1e-8) + ref.mean()
        del forward
        comfy.model_management.soft_empty_cache()

        if sr != model_sr:
            voice = torchaudio.functional.resample(voice, model_sr, sr)
        voice = voice[:, :n_in]
        if voice.shape[-1] < n_in:
            voice = torch.nn.functional.pad(voice, (0, n_in - voice.shape[-1]))
        if wav.shape[0] == 1:
            voice = voice.mean(0, keepdim=True)
        rest = wav - voice
        return ({"waveform": voice[None], "sample_rate": sr}, {"waveform": rest[None], "sample_rate": sr})


class SceneSaveAudioWav:
    """Save audio as 24-bit PCM wav, sample for sample (no resampling, no padding)."""

    @classmethod
    def INPUT_TYPES(cls):
        return {"required": {"audio": ("AUDIO",), "filename_prefix": ("STRING", {"default": "scene_ai/audio"})}}

    RETURN_TYPES = ()
    OUTPUT_NODE = True
    FUNCTION = "save"
    CATEGORY = "scene_ai"

    def save(self, audio, filename_prefix):
        full_dir, name, counter, subfolder, _ = folder_paths.get_save_image_path(filename_prefix, folder_paths.get_output_directory())
        results = []
        for b, wav in enumerate(audio["waveform"]):
            pcm = (wav.float().clamp(-1, 1 - 2 ** -23) * 2 ** 23).round().to(torch.int32).T.contiguous().numpy()
            data = pcm.astype("<i4").view("u1").reshape(-1, 4)[:, :3].tobytes()
            fname = f"{name}_{counter + b:05}_.wav"
            with wave.open(os.path.join(full_dir, fname), "wb") as f:
                f.setnchannels(wav.shape[0])
                f.setsampwidth(3)
                f.setframerate(audio["sample_rate"])
                f.writeframes(data)
            results.append({"filename": fname, "subfolder": subfolder, "type": "output"})
        return {"ui": {"audio": results}}


NODE_CLASS_MAPPINGS = {
    "SceneQwenEditRefs": SceneQwenEditRefs,
    "SceneAspectSize": SceneAspectSize,
    "SceneVoiceSeparate": SceneVoiceSeparate,
    "SceneH3Chunk": SceneH3Chunk,
    "SceneH3ShotPins": SceneH3ShotPins,
    "SceneTranscribe": SceneTranscribe,
    "SceneSaveAudioWav": SceneSaveAudioWav,
    "SceneLipSync": SceneLipSync,
}
NODE_DISPLAY_NAME_MAPPINGS = {
    "SceneQwenEditRefs": "Qwen Edit: up to 6 references (Scene.ai)",
    "SceneAspectSize": "Aspect ratio to size (Scene.ai)",
    "SceneVoiceSeparate": "Separate voice (HDemucs, chunked) (Scene.ai)",
    "SceneH3Chunk": "H3 chunk: 9 reference slots, seconds (Scene.ai)",
    "SceneH3ShotPins": "H3 shot keyframes at cut frames (Scene.ai)",
    "SceneTranscribe": "Transcribe: Whisper + forced alignment + speakers (Scene.ai)",
    "SceneSaveAudioWav": "Save Audio (WAV 24-bit) (Scene.ai)",
    "SceneLipSync": "Lip sync: LatentSync 1.6, face choice (Scene.ai)",
}
